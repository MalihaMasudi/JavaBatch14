package com.syntax.class07;

public class DoWhileDemo {
	
	public static void main(String[] args) {
		
		int num=1;
		
		while(num<=2) {
			System.out.println("I am while loop");
			num++;
		}
		
		System.out.println(" -------------------  ");
		
		int num1=1;
		
		do {
			System.out.println("I am do while loop");
			num1++;
			
		}while(num1<=2);
		
	}
}
