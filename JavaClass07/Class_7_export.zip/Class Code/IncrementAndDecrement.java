package com.syntax.class07;

public class IncrementAndDecrement {

	public static void main(String[] args) {
		
		int num=90;
		num=num+1;
		System.out.println(num);//91
		
		//another way to increment variable value by 1 -> ++
		num++; //+1
		System.out.println(num);//92
		
		//to decrement a value of a variable by 1 -> --
		num--;
		System.out.println(num);//91
		
		int i=10;
		i--;
		i--;
		System.out.println(i);
	}
}
