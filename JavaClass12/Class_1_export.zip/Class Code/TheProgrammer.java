package com.syntax.class01;

public class TheProgrammer {

	public static void main(String[] args) {
		
		//This is my third Java Program
		
		System.out.print("I am a Java Programmer");
		
		System.out.print("Hello");
		
		System.out.println("Break is coming");
		
		System.out.print("Bye");
		
		/* print vs println
		 * print -> just prints
		 * println -> prints and creates a new line
		 */

	}
}
