package com.syntax.class01;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("My name is Erik");
		
		System.out.println("Hello Batch 14");
		
		System.out.println(20);
	
	}

}
