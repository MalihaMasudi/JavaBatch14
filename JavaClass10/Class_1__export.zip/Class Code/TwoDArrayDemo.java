package com.syntax.class10;

public class TwoDArrayDemo {
	
	public static void main(String[] args) {
		
		int[][] arr= {
				{10, 20, 30, 40}, //1 array
				{100, 200, 300, 400},// 2 array
				{1,2,3,4} //3 array
		};
		
		System.out.println(arr[0][1]); //20
		
	}
}
